class DailyDownload < ActiveRecord::Base
end
