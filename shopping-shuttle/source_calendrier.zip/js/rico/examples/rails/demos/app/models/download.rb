class Download < ActiveRecord::Base

end
