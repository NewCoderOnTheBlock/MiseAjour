class DemosController < ApplicationController
  layout "demos"

  def index
  end              
end
