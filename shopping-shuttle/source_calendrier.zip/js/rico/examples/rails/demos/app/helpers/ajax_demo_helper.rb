module AjaxDemoHelper
end
