+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
++                                                                       ++
++                                                                       ++
++             Module "Calendrier" avec AJAX                             ++
++             Source : http://www.developpez.com                        ++
++                                                                       ++
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Installation
-------------

Pour executer ce script, veuillez tout d'abord cr�er une base de donn�es MYSQL sur votre serveur web.
Une fois la base cr�er, vous pouvez peupler votre base � l'aide du script "equetes.sql" situ� dans le r�pertoire sql.

Maintenant vous pouver ouvrir le fichier mysql.php situ� dans le r�pertoire conf et modifier les param�tres de connexion mysql
avec vos param�tres ( nom du servuer, nom de la base de donn�es, login et mot de passe).

Lancer l'application en ouvrant avec l'url http://localhost/calendrier.php ( � modifier en fonction de votre environnement).